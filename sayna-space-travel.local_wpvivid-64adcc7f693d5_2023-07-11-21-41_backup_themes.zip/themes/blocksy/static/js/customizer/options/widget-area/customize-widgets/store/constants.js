/**
 * Module Constants
 */
export const STORE_NAME = 'core/customize-widgets'
